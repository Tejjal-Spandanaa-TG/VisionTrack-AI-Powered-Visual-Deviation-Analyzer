import { Hero } from "@/components/hero"
import { ProblemSolution } from "@/components/problem-solution"
import { TechnicalArchitecture } from "@/components/technical-architecture"
import { Workflow } from "@/components/workflow"
import { UseCases } from "@/components/use-cases"
import { Impact } from "@/components/impact"
import { BonusExtensions } from "@/components/bonus-extensions"
import { Implementation } from "@/components/implementation"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Hero />
      <ProblemSolution />
      <TechnicalArchitecture />
      <Workflow />
      <UseCases />
      <Impact />
      <BonusExtensions />
      <Implementation />
      <Footer />
    </main>
  )
}
