"use client"

import { Card } from "@/components/ui/card"
import { Zap } from "lucide-react"

export function BonusExtensions() {
  const extensions = [
    {
      title: "Multi-Modal Fusion",
      description: "Combine visual data with thermal, LiDAR, and spectral imaging for comprehensive analysis",
      impact: "Detect subsurface defects and material degradation",
    },
    {
      title: "Federated Learning",
      description: "Train models across distributed devices without centralizing sensitive data",
      impact: "Privacy-preserving AI for regulated industries",
    },
    {
      title: "Predictive Degradation",
      description: "Use time-series analysis to forecast failure timelines and maintenance windows",
      impact: "Proactive maintenance scheduling and cost optimization",
    },
    {
      title: "Mobile AR App",
      description: "Field inspectors use smartphones to overlay AI insights on real-world objects",
      impact: "Instant on-site decision making and documentation",
    },
    {
      title: "Marketplace Integration",
      description: "Connect with drone operators, IoT platforms, and enterprise systems via APIs",
      impact: "Seamless workflow integration and ecosystem expansion",
    },
    {
      title: "Generative Reports",
      description: "AI-generated executive summaries, recommendations, and compliance documents",
      impact: "Automated reporting and stakeholder communication",
    },
  ]

  return (
    <section className="py-20 px-4 bg-slate-950">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-4">
          <Zap className="w-6 h-6 text-yellow-400" />
          <h2 className="text-4xl font-bold text-white">Bonus Extensions</h2>
        </div>
        <p className="text-slate-400 mb-16 max-w-2xl">
          Future-proof features to expand VisionTrack's capabilities and market reach
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {extensions.map((ext, idx) => (
            <Card key={idx} className="bg-slate-800 border-slate-700 p-6 hover:border-yellow-600/50 transition">
              <h3 className="text-lg font-bold text-white mb-2">{ext.title}</h3>
              <p className="text-sm text-slate-300 mb-4">{ext.description}</p>
              <div className="pt-4 border-t border-slate-700">
                <p className="text-xs text-yellow-400 font-semibold">💡 {ext.impact}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
