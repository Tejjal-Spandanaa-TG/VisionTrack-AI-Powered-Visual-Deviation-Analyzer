"use client"

import { ArrowRight, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 px-4">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 mb-8">
          <Eye className="w-4 h-4 text-blue-400" />
          <span className="text-sm font-medium text-blue-300">Visual Difference Engine Challenge</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
          VisionTrack
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
            AI-Powered Visual Deviation Analyzer
          </span>
        </h1>

        <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto leading-relaxed">
          Detect, classify, and visualize visual changes across time-series images with AI-driven precision. From
          manufacturing floors to infrastructure inspections, see what matters.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
            View Full Concept <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-slate-600 text-slate-200 hover:bg-slate-800 bg-transparent"
          >
            Download Deck
          </Button>
        </div>

        <div className="mt-16 grid grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-blue-400">AI</div>
            <p className="text-sm text-slate-400 mt-2">CNN-Powered Detection</p>
          </div>
          <div>
            <div className="text-3xl font-bold text-cyan-400">☁️</div>
            <p className="text-sm text-slate-400 mt-2">Cloud Automation</p>
          </div>
          <div>
            <div className="text-3xl font-bold text-blue-400">AR</div>
            <p className="text-sm text-slate-400 mt-2">Real-Time Visualization</p>
          </div>
        </div>
      </div>
    </section>
  )
}
