"use client"

import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

export function Implementation() {
  const phases = [
    {
      phase: "Phase 1: MVP (Months 1-3)",
      items: [
        "Build Siamese network for image comparison",
        "Develop cloud pipeline (AWS Lambda + S3)",
        "Create basic web dashboard with heatmap visualization",
        "Integrate with one drone platform (DJI)",
        "Pilot with manufacturing partner",
      ],
    },
    {
      phase: "Phase 2: Scale (Months 4-6)",
      items: [
        "Add AR visualization module",
        "Implement attention map explainability",
        "Build mobile app for field inspectors",
        "Expand to 3+ drone/IoT platforms",
        "Launch SaaS pricing model",
      ],
    },
    {
      phase: "Phase 3: Enterprise (Months 7-12)",
      items: [
        "Multi-modal sensor fusion (thermal, LiDAR)",
        "Federated learning for privacy",
        "Predictive degradation models",
        "API marketplace and integrations",
        "Global deployment and compliance certifications",
      ],
    },
  ]

  return (
    <section className="py-20 px-4 bg-slate-900">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-white mb-4 text-center">Implementation Roadmap</h2>
        <p className="text-slate-400 text-center mb-16 max-w-2xl mx-auto">
          12-month plan to go from MVP to enterprise-grade platform
        </p>

        <div className="grid md:grid-cols-3 gap-6">
          {phases.map((phase, idx) => (
            <Card key={idx} className="bg-slate-800 border-slate-700 p-8">
              <h3 className="text-lg font-bold text-white mb-6">{phase.phase}</h3>
              <ul className="space-y-3">
                {phase.items.map((item, i) => (
                  <li key={i} className="flex gap-3 text-sm text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>

        {/* Success Metrics */}
        <Card className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border-blue-700/50 p-8 mt-12">
          <h3 className="text-2xl font-bold text-white mb-6">Success Metrics</h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div>
              <div className="text-2xl font-bold text-blue-400 mb-2">1000+</div>
              <p className="text-sm text-slate-300">Assets monitored</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-cyan-400 mb-2">99.9%</div>
              <p className="text-sm text-slate-300">Platform uptime</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-400 mb-2">50ms</div>
              <p className="text-sm text-slate-300">Analysis latency</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-cyan-400 mb-2">$5M</div>
              <p className="text-sm text-slate-300">ARR target (Year 2)</p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  )
}
