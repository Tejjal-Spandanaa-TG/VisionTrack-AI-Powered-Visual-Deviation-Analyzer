"use client"

import { Card } from "@/components/ui/card"
import { Factory, Building2, Leaf, CheckSquare } from "lucide-react"

export function UseCases() {
  const useCases = [
    {
      icon: Factory,
      title: "Manufacturing QA",
      description: "Detect paint defects, surface cracks, and assembly errors on production lines",
      metrics: ["95% defect detection", "10x faster inspection", "$2M annual savings"],
    },
    {
      icon: Building2,
      title: "Infrastructure Maintenance",
      description: "Monitor bridges, roads, and buildings for structural degradation over time",
      metrics: ["Predictive maintenance", "Reduce downtime 40%", "Safety compliance"],
    },
    {
      icon: Leaf,
      title: "Environmental Monitoring",
      description: "Track deforestation, crop health, and land-use changes via satellite/drone imagery",
      metrics: ["Real-time alerts", "Regulatory reporting", "Carbon tracking"],
    },
    {
      icon: CheckSquare,
      title: "Brand Compliance",
      description: "Verify retail displays, packaging, and store conditions match brand standards",
      metrics: ["100% audit coverage", "Instant compliance", "Audit trail"],
    },
  ]

  return (
    <section className="py-20 px-4 bg-slate-950">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-white mb-4 text-center">Use Cases</h2>
        <p className="text-slate-400 text-center mb-16 max-w-2xl mx-auto">Proven applications across industries</p>

        <div className="grid md:grid-cols-2 gap-6">
          {useCases.map((useCase, idx) => {
            const Icon = useCase.icon
            return (
              <Card key={idx} className="bg-slate-800 border-slate-700 p-8 hover:border-blue-600/50 transition">
                <Icon className="w-10 h-10 text-blue-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">{useCase.title}</h3>
                <p className="text-slate-300 mb-6">{useCase.description}</p>
                <div className="space-y-2">
                  {useCase.metrics.map((metric, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-slate-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                      {metric}
                    </div>
                  ))}
                </div>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
