"use client"

import { Card } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export function Workflow() {
  const steps = [
    {
      num: "1",
      title: "Capture",
      description: "Drone/IoT device captures image with metadata",
      details: ["GPS coordinates", "Timestamp", "Device ID", "Environmental data"],
    },
    {
      num: "2",
      title: "Upload",
      description: "Image auto-syncs to cloud via secure API",
      details: ["Encrypted transfer", "Duplicate detection", "Metadata indexing", "Queue management"],
    },
    {
      num: "3",
      title: "Analyze",
      description: "AI compares with baseline/previous images",
      details: ["Siamese network inference", "Change detection", "Heatmap generation", "Classification"],
    },
    {
      num: "4",
      title: "Explain",
      description: "Attention maps show why changes were detected",
      details: ["Grad-CAM visualization", "Confidence scores", "Change type labels", "Severity ranking"],
    },
    {
      num: "5",
      title: "Visualize",
      description: "Inspector views results in dashboard or AR",
      details: ["Interactive heatmaps", "AR overlay", "Historical trends", "Comparison tools"],
    },
    {
      num: "6",
      title: "Act",
      description: "Generate reports and trigger workflows",
      details: ["PDF export", "Compliance docs", "Alert notifications", "Task assignment"],
    },
  ]

  return (
    <section className="py-20 px-4 bg-slate-900">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-white mb-4 text-center">User Workflow</h2>
        <p className="text-slate-400 text-center mb-16 max-w-2xl mx-auto">
          From image capture to actionable insights in minutes
        </p>

        <div className="grid md:grid-cols-3 gap-6">
          {steps.map((step, idx) => (
            <div key={idx}>
              <Card className="bg-slate-800 border-slate-700 p-6 h-full hover:border-blue-600/50 transition">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                    {step.num}
                  </div>
                  <h3 className="text-lg font-bold text-white">{step.title}</h3>
                </div>
                <p className="text-slate-300 mb-4">{step.description}</p>
                <ul className="text-xs text-slate-400 space-y-1">
                  {step.details.map((detail, i) => (
                    <li key={i} className="flex gap-2">
                      <span className="text-blue-400">→</span>
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </Card>
              {idx < steps.length - 1 && (
                <div className="hidden md:flex justify-center mt-6">
                  <ArrowRight className="w-6 h-6 text-slate-600 rotate-90" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
